# Chapter X. 파이썬 파일 입출력 (Reading and Writing Files): 단계별 학습 가이드

> 출처: *Reading and Writing Files in Python (Guide)* — Real Python
> [https://realpython.com/read-write-files-python/](https://realpython.com/read-write-files-python/)

---

## 학습 목표 (Learning Objectives)

이 장을 마치면 학생들은 다음을 할 수 있습니다:

1. **파일(file)** 이 무엇인지, 그리고 파일 경로, 줄 바꿈 문자, 문자 인코딩의 역할을 설명할 수 있다.
2. `open()`과 `with` 문을 사용하여 파일을 안전하게 **열고 닫을** 수 있다.
3. 작업에 맞는 올바른 **파일 모드**(`r`, `w`, `a`, `rb`, `wb`)를 선택할 수 있다.
4. `.read()`, `.readline()`, `.readlines()`, 직접 순회를 사용하여 파일을 **읽을** 수 있다.
5. `.write()`와 `.writelines()`를 사용하여 파일에 **쓸** 수 있다.
6. 기존 파일에 내용을 **이어쓸(append)** 수 있다.
7. **이진(binary) 데이터**를 바이트 문자열과 `b` 모드 플래그로 다룰 수 있다.
8. 하나의 `with` 문에서 **두 파일을 동시에** 다룰 수 있다.

---

## 목차 (Table of Contents)

| # | 주제 | 핵심 개념 |
|---|---|---|
| 1 | 파일이란? | 헤더 / 데이터 / EOF |
| 2 | 파일 경로 | 절대, 상대, `..` |
| 3 | 줄 바꿈 & 인코딩 | `\r\n` vs `\n`, UTF-8 |
| 4 | 파일 열기 & 닫기 | `open()`, `with` |
| 5 | 파일 모드 | `r`, `w`, `a`, `rb`, `wb` |
| 6 | 파일 읽기 | `.read()`, `.readline()`, `.readlines()`, 순회 |
| 7 | 파일 쓰기 | `.write()`, `.writelines()` |
| 8 | 이어쓰기 | 모드 `'a'` |
| 9 | 이진 파일 | 모드 `'rb'` / `'wb'` |
| 10 | 두 파일 동시에 | 결합된 `with` |

---

## 1단계. 파일이란?

본질적으로 파일은 디스크에 저장된 **연속된 바이트(byte)의 시퀀스**입니다. 대부분의 현대 운영체제에서 파일은 세 부분으로 구성됩니다:

| 부분 | 역할 |
|---|---|
| **헤더(Header)** | 메타데이터 (이름, 크기, 타입 등) |
| **데이터(Data)** | 작성자가 작성한 실제 내용 |
| **파일 끝(EOF)** | 파일이 끝나는 지점을 표시하는 특수 문자 |

데이터의 의미는 파일의 **형식(format)** 에 따라 다르며, 보통 `.txt`, `.csv`, `.png`, `.gif` 같은 **확장자(extension)** 로 표시됩니다. 이 장에서는 `.txt`와 `.csv` 파일에 집중합니다.

---

## 2단계. 파일 경로 (File Paths)

**파일 경로**는 운영체제에게 파일의 위치를 알려주는 문자열입니다. 세 부분으로 구성됩니다:

1. **폴더 경로(Folder Path)** — 디렉토리 위치 (Unix/macOS는 `/`, Windows는 `\` 사용).
2. **파일 이름(File Name)** — 파일 자체의 이름.
3. **확장자(Extension)** — `.`로 시작하며 파일 종류를 표시.

### 2.1 예시 폴더 구조

```
/
│
├── path/
|   │
│   ├── to/
│   │   └── cats.gif
│   │
│   └── dog_breeds.txt
|
└── animals.csv
```

### 2.2 경로 예시

| 현재 작업 디렉토리 | 접근할 파일 | 작성할 경로 |
|---|---|---|
| `/` | `cats.gif` | `path/to/cats.gif` |
| `/path/to/` | `cats.gif` | `cats.gif` |
| `/path/to/` | `dog_breeds.txt` | `../dog_breeds.txt` |
| `/path/to/` | `animals.csv` | `../../animals.csv` |

> **팁:** 점 두 개 `..`는 "상위 디렉토리로 이동"을 의미합니다. 연결할 수 있습니다: `../../file.txt`는 두 단계 위로 올라갑니다.

---

## 3단계. 줄 바꿈 문자와 문자 인코딩

### 3.1 줄 바꿈 문자 (Line Endings)

운영체제마다 한 줄의 끝을 표시하는 방식이 다릅니다:

| 플랫폼 | 줄 바꿈 | 문자 |
|---|---|---|
| Windows | `CR + LF` | `\r\n` |
| Unix / 최신 macOS | `LF` | `\n` |

따라서 Windows에서 만든 파일이 리눅스에서 이상하게 보일 수 있고, 그 반대도 마찬가지입니다. 다른 출처의 파일을 처리할 때 주의하세요.

### 3.2 문자 인코딩 (Character Encodings)

**인코딩**은 바이트를 사람이 읽을 수 있는 문자로 변환합니다.

| 인코딩 | 지원 문자 수 |
|---|---|
| ASCII | 128자 |
| Unicode (UTF-8) | 최대 1,114,112자 |

ASCII는 UTF-8의 부분집합입니다. UTF-8 파일을 ASCII로 읽으려 할 때 비ASCII 문자(예: `é`, `한`, `中`)가 있으면 오류가 발생합니다. **확신이 없으면 `encoding="utf-8"`을 사용하세요.**

> **한국어 사용자에게 특히 중요:** 한글이 포함된 파일을 다룰 때는 항상 `encoding="utf-8"`을 명시하세요. 그렇지 않으면 Windows에서 `cp949`로 잘못 해석되어 문자가 깨질 수 있습니다.

---

## 4단계. 파일 열기와 닫기

### 4.1 `open()` 함수

```python
file = open('dog_breeds.txt')
```

`open()`은 경로를 받아 **파일 객체(file object)** 를 반환합니다. 작업이 끝나면 **반드시** 닫아야 합니다.

### 4.2 ❌ 닫는 것을 잊으면

파일이 잠긴 상태로 남거나, 자원이 누수되거나, 디스크에 아직 기록되지 않은 데이터가 손실될 수 있습니다.

### 4.3 ⚠️ `try` … `finally`로 닫기

```python
reader = open('dog_breeds.txt')
try:
    # reader로 무언가 작업
    ...
finally:
    reader.close()
```

이 방법은 작동하지만 장황합니다.

### 4.4 ✅ 파이썬다운 방법: `with` 문

```python
with open('dog_breeds.txt') as reader:
    # reader로 무언가 작업
    ...
# 블록을 빠져나오면 파일이 자동으로 닫힘 (예외가 발생해도)
```

`with` 문은 **컨텍스트 매니저(context manager)** 입니다 — 예외 발생 여부와 관계없이 블록을 떠날 때 파일이 닫히는 것을 보장합니다.

> **모범 사례:** 항상 `with open(...)`을 사용하세요. 더 짧고, 더 안전하며, 더 파이썬다운 방식입니다.

---

## 5단계. 파일 모드 (File Modes)

`open()`의 두 번째 인자는 **모드(mode)** 입니다:

| 모드 | 의미 | 파일 생성? | 내용 삭제? |
|---|---|---|---|
| `'r'` | 읽기 (기본값) | 아니오 (없으면 오류) | 아니오 |
| `'w'` | 쓰기 | 예 | **예 — 덮어쓰기!** |
| `'a'` | 이어쓰기 | 예 | 아니오 (끝에 추가) |
| `'rb'` | 이진 읽기 | 아니오 | 아니오 |
| `'wb'` | 이진 쓰기 | 예 | 예 |
| `'r+'` | 읽기 및 쓰기 | 아니오 | 아니오 |

> ⚠️ **경고:** `'w'`로 파일을 열면 쓰기 전에 **기존 내용을 모두 삭제**합니다. 내용을 보존하면서 추가하려면 `'a'`를 사용하세요.

```python
with open('dog_breeds.txt', 'r') as reader:
    ...
```

---

## 6단계. 파일 읽기

파일이 열린 후 읽는 방법은 여러 가지가 있습니다:

| 메서드 | 반환 | 사용 시점 |
|---|---|---|
| `.read(size=-1)` | 파일 전체를 하나의 문자열로 | 작은 파일에만 |
| `.readline(size=-1)` | 한 줄 (문자열) | 한 줄씩 처리할 때 |
| `.readlines()` | 모든 줄의 리스트 | 인덱스 접근이 필요할 때 |
| `for line in file:` | 한 번에 한 줄씩 순회 | **가장 파이썬다운, 가장 메모리 효율적** |

### 6.1 파일 전체 읽기

```python
with open('dog_breeds.txt', 'r') as reader:
    print(reader.read())
```

### 6.2 `.readline()`으로 한 줄씩 읽기

```python
with open('dog_breeds.txt', 'r') as reader:
    line = reader.readline()
    while line != '':   # 빈 문자열은 EOF를 의미
        print(line, end='')
        line = reader.readline()
```

### 6.3 모든 줄을 리스트로 읽기

```python
with open('dog_breeds.txt', 'r') as reader:
    lines = reader.readlines()
# lines == ['Pug\n', 'Jack Russell Terrier\n', ...]
```

> **참고:** `.readlines()`는 각 줄 끝의 `\n`을 그대로 유지합니다.

### 6.4 ✅ 가장 좋은 방법: 파일 객체 직접 순회

```python
with open('dog_breeds.txt', 'r') as reader:
    for line in reader:
        print(line, end='')
```

이 방법은 파일 전체를 메모리에 올리지 않고 한 줄씩 읽으므로 큰 파일에 대해 더 빠르고 안전합니다.

> **왜 `end=''`?** 각 `line`이 이미 `\n`으로 끝납니다. `print()`가 또 `\n`을 추가하면 출력에 빈 줄이 생깁니다.

---

## 7단계. 파일 쓰기

| 메서드 | 동작 |
|---|---|
| `.write(string)` | 문자열을 파일에 씁니다. 작성된 문자 수를 반환합니다. |
| `.writelines(seq)` | 문자열의 시퀀스를 씁니다. **줄 바꿈을 자동으로 추가하지 않습니다** — `\n`을 직접 넣어야 합니다. |

### 7.1 한 문자열 쓰기

```python
with open('greeting.txt', 'w') as writer:
    writer.write("안녕하세요, 세계!\n")
```

### 7.2 여러 줄 쓰기

```python
lines = ["진돗개\n", "삽살개\n", "풍산개\n"]
with open('dogs.txt', 'w', encoding='utf-8') as writer:
    writer.writelines(lines)
```

### 7.3 읽기 + 쓰기: 파일 뒤집기

```python
with open('dog_breeds.txt', 'r') as reader:
    breeds = reader.readlines()

with open('dog_breeds_reversed.txt', 'w') as writer:
    for breed in reversed(breeds):
        writer.write(breed)
```

---

## 8단계. 파일에 이어쓰기

`'a'` 모드를 사용하면 기존 파일의 **끝에** 내용을 추가할 수 있습니다 (기존 내용을 삭제하지 않음):

```python
with open('dog_breeds.txt', 'a') as a_writer:
    a_writer.write('\nBeagle')
```

이 코드를 실행하면 원본 내용이 보존되고 끝에 `Beagle`이 추가됩니다.

> **비교:**
> - `'w'` → 삭제 후 쓰기 (파괴적)
> - `'a'` → 보존 후 끝에 추가 (안전)

---

## 9단계. 바이트 다루기 (이진 파일)

모드에 `'b'`를 추가하면 텍스트 대신 원시 바이트로 작업할 수 있습니다. 메서드는 동일하지만 `bytes` 객체를 반환합니다 (`b''` 접두사 주목):

```python
with open('dog_breeds.txt', 'rb') as reader:
    print(reader.readline())
# b'Pug\n'
```

### 9.1 왜 이진 모드인가?

이진 모드는 이미지, 오디오, 비디오, 실행 파일, zip 압축 파일 같은 비텍스트 파일에 필수입니다.

### 9.2 예시: PNG 헤더 읽기

PNG 파일은 항상 다음 8개의 매직 바이트로 시작합니다:

| 바이트 | 의미 |
|---|---|
| `0x89` | PNG 매직 넘버 |
| `0x50 0x4E 0x47` | ASCII로 `PNG` |
| `0x0D 0x0A` | DOS 스타일 줄 바꿈 `\r\n` |
| `0x1A` | DOS EOF 문자 |
| `0x0A` | Unix 줄 바꿈 `\n` |

```python
with open('jack_russell.png', 'rb') as byte_reader:
    print(byte_reader.read(1))  # b'\x89'
    print(byte_reader.read(3))  # b'PNG'
    print(byte_reader.read(2))  # b'\r\n'
    print(byte_reader.read(1))  # b'\x1a'
    print(byte_reader.read(1))  # b'\n'
```

---

## 10단계. 두 파일 동시에 다루기

하나의 `with` 문에서 두 파일을 열 수 있습니다:

```python
with open('source.txt', 'r') as reader, open('dest.txt', 'w') as writer:
    for line in reader:
        writer.write(line.upper())
```

블록이 끝나면 두 파일 모두 올바르게 닫힙니다.

이 패턴은 **파일 변환 작업**에 완벽합니다: 한 파일에서 읽고, 데이터를 변환하고, 결과를 다른 파일에 씁니다.

---

## 미니 프로젝트: `dos2unix.py`

지금까지 배운 모든 것을 결합하여 Windows 줄 바꿈(`\r\n`)을 Unix 줄 바꿈(`\n`)으로 변환합니다:

```python
def str2unix(input_str: str) -> str:
    """문자열의 \\r\\n 줄 바꿈을 \\n으로 변환."""
    return input_str.replace('\r\n', '\n')


def dos2unix(source_file: str, dest_file: str) -> None:
    """DOS 스타일 파일을 Unix 스타일 파일로 변환."""
    with open(source_file, 'r') as reader:
        dos_content = reader.read()

    unix_content = str2unix(dos_content)

    with open(dest_file, 'w') as writer:
        writer.write(unix_content)
```

이 작은 스크립트는 다음을 보여줍니다: 파일 전체 읽기, 텍스트 변환, 새 파일에 쓰기.

---

## 메서드 정리

### 읽기
| 메서드 | 반환 |
|---|---|
| `.read()` | 파일 전체를 하나의 문자열로 |
| `.readline()` | 다음 한 줄을 문자열로 |
| `.readlines()` | 남은 모든 줄을 리스트로 |
| `for line in f:` | 반복마다 한 줄 (선호됨) |

### 쓰기
| 메서드 | 비고 |
|---|---|
| `.write(s)` | 한 문자열을 씀; 자동 줄 바꿈 없음 |
| `.writelines(seq)` | 여러 문자열을 씀; 자동 줄 바꿈 없음 |

### 모드
| 모드 | 읽기 | 쓰기 | 이어쓰기 | 이진 |
|---|---|---|---|---|
| `'r'` | ✅ | ❌ | ❌ | ❌ |
| `'w'` | ❌ | ✅ (덮어쓰기) | ❌ | ❌ |
| `'a'` | ❌ | ✅ (끝에) | ✅ | ❌ |
| `'rb'` | ✅ | ❌ | ❌ | ✅ |
| `'wb'` | ❌ | ✅ | ❌ | ✅ |

---

## 자주 하는 실수 체크리스트

- ❌ 파일 닫기를 잊음 (단순 `open()` 대신 `with` 사용).
- ❌ `'a'`를 원했는데 `'w'`로 열기 — 데이터가 사라짐!
- ❌ 10 GB 파일을 `.read()`로 한 번에 — 메모리 부족.
- ❌ 줄을 읽을 때 `print()`에 `end=''`를 빼먹음 — 빈 줄이 생김.
- ❌ `.write()` 또는 `.writelines()`에 `\n`을 빼먹음 — 모두 한 줄에 붙음.
- ❌ `encoding="utf-8"` 없이 UTF-8 파일 읽기 (특히 Windows에서).
- ✅ 항상 `with open(...) as f:` 사용.
- ✅ 큰 파일에는 `for line in f:` 순회 사용.
- ✅ 한국어 등 비영어 텍스트를 다룰 때는 명시적으로 `encoding="utf-8"` 지정.

---

## 더 읽을거리

- 파이썬 공식 문서 — `open()` 내장 함수: <https://docs.python.org/3/library/functions.html#open>
- Real Python — 파일을 닫는 것이 왜 중요한가?: <https://realpython.com/why-close-file-python/>
- Real Python — `with` 문 활용: <https://realpython.com/python-with-statement/>
- Real Python — CSV 파일 읽기/쓰기: <https://realpython.com/python-csv/>
- Real Python — JSON 데이터 다루기: <https://realpython.com/python-json/>
- Real Python — Python 인코딩 가이드: <https://realpython.com/python-encodings-guide/>
