# Chapter X. 파이썬 예외 처리 (Python Exceptions): 단계별 학습 가이드

> 출처: *Python Exceptions: An Introduction* — Real Python
> [https://realpython.com/python-exceptions/](https://realpython.com/python-exceptions/)

---

## 학습 목표 (Learning Objectives)

이 장을 마치면 학생들은 다음을 할 수 있습니다:

1. **구문 오류(syntax error)** 와 **예외(exception)** 의 차이를 구분할 수 있다.
2. `raise` 키워드를 사용하여 예외를 의도적으로 **발생(raise)** 시킬 수 있다.
3. `assert`를 사용하여 개발 단계에서 조건을 검증할 수 있다.
4. `try` … `except` 블록을 사용하여 예외를 **잡고 처리(catch and handle)** 할 수 있다.
5. `else`와 `finally` 절을 사용하여 보다 정교한 예외 처리를 할 수 있다.
6. 내장 예외 클래스를 상속하여 **사용자 정의 예외(custom exception)** 를 만들 수 있다.
7. **나쁜 관행**(예: bare `except`, 조용히 `pass`)을 식별하고 피할 수 있다.

---

## 목차 (Table of Contents)

| # | 주제 | 핵심 키워드 |
|---|---|---|
| 1 | 구문 오류 vs. 예외 | — |
| 2 | 예외 발생시키기 | `raise` |
| 3 | 단정문(assert)으로 디버깅 | `assert` |
| 4 | 예외 처리하기 | `try` / `except` |
| 5 | 성공 시에만 실행 | `else` |
| 6 | 자원 정리하기 | `finally` |
| 7 | 사용자 정의 예외 | `class` + `Exception` |

---

## 1단계. 구문 오류 vs. 예외

### 1.1 구문 오류(Syntax Error)란?

**구문 오류**는 프로그램이 *실행되기 전에* 파이썬 파서(parser)가 감지합니다. 코드 자체가 문법적으로 잘못되어 파이썬이 이해할 수 없는 상태입니다.

```python
>>> print(0 / 0))
  File "<stdin>", line 1
    print(0 / 0))
                ^
SyntaxError: unmatched ')'
```

화살표(`^`)는 파서가 어디에서 혼란스러워했는지 정확히 보여줍니다. 이 경우, 닫는 괄호가 하나 더 있습니다.

### 1.2 예외(Exception)란?

**예외**는 *문법적으로 올바른* 코드가 실행 중 오류를 만났을 때 발생합니다.

```python
>>> print(0 / 0)
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
ZeroDivisionError: division by zero
```

코드는 문법적으로 유효하지만, 0으로 나누는 것은 수학적으로 정의되지 않으므로 파이썬이 실행 중 `ZeroDivisionError`를 발생시킵니다.

### 1.3 비교표

| 구분 | 구문 오류 (Syntax Error) | 예외 (Exception) |
|---|---|---|
| 감지 시점 | 파서 (실행 이전) | 인터프리터 (실행 중) |
| 원인 | 잘못된 문법 | 유효한 코드의 잘못된 연산 |
| 예시 | `print(0 / 0))` | `print(0 / 0)` |
| 클래스 이름 | `SyntaxError` | `ZeroDivisionError`, `ValueError` 등 |

---

## 2단계. `raise`로 예외 발생시키기

원치 않는 조건이 발생했을 때 프로그램을 *즉시* 멈추고 싶을 때가 있습니다. 이때 `raise` 키워드를 사용합니다.

### 2.1 기본 문법

```python
raise <예외타입>(<선택적 메시지>)
```

### 2.2 예시: 5보다 큰 숫자 거부하기

```python
# low.py
number = 10
if number > 5:
    raise Exception(f"숫자는 5를 초과해서는 안 됩니다. ({number=})")
print(number)
```

**출력 결과:**

```
Traceback (most recent call last):
  File "./low.py", line 3, in <module>
    raise Exception(f"숫자는 5를 초과해서는 안 됩니다. ({number=})")
Exception: 숫자는 5를 초과해서는 안 됩니다. (number=10)
```

### 2.3 핵심 관찰 사항

- 프로그램이 `raise` 문에서 **중단**됩니다.
- 마지막 `print(number)`는 **절대 실행되지 않습니다**.
- f-string의 `{number=}`는 *자기 문서화 표현식(self-documenting expression)* 으로, 변수 이름과 값을 함께 출력합니다.

> **모범 사례:** 가능한 한 가장 구체적인 내장 예외(예: `ValueError`, `TypeError`)를 선택하세요. 일반적인 `Exception`은 가급적 피합니다.

---

## 3단계. `assert`로 디버깅하기

`assert` 키워드는 **개발 단계**용 도구입니다. 조건을 검사하여 조건이 `False`이면 `AssertionError`를 발생시킵니다.

### 3.1 문법

```python
assert <조건>, <선택적 오류 메시지>
```

### 3.2 예시

```python
# low.py
number = 10
assert (number < 5), f"숫자는 5를 초과해서는 안 됩니다. ({number=})"
print(number)
```

**출력 결과:**

```
Traceback (most recent call last):
  File "./low.py", line 2, in <module>
    assert (number < 5), f"숫자는 5를 초과해서는 안 됩니다. ({number=})"
AssertionError: 숫자는 5를 초과해서는 안 됩니다. (number=10)
```

### 3.3 ⚠️ 중요한 경고

파이썬을 최적화 모드로 실행하면 단정문이 **전역적으로 비활성화**됩니다:

```bash
$ python -O low.py
10
```

`-O` 플래그를 사용하면 `assert` 문이 완전히 제거되어, 위험한 값이 조용히 통과해 버립니다.

> **원칙:**
> - ✅ `assert`는 개발 중 **디버깅**과 **사전 검증(sanity check)** 에 사용합니다.
> - ❌ 운영(production) 환경의 **핵심 비즈니스 규칙**을 강제하는 데는 절대 `assert`를 쓰지 마세요. 대신 `raise`를 사용하세요.

---

## 4단계. `try`와 `except`로 예외 처리하기

`try` … `except` 블록은 프로그램이 충돌하지 않고 예외를 **잡아서(catch)** 우아하게 대응할 수 있게 해줍니다.

### 4.1 기본 구조

```python
try:
    # 예외가 발생할 수 있는 코드
    risky_operation()
except SomeExceptionType:
    # 예외가 발생했을 때만 실행되는 코드
    handle_the_error()
```

### 4.2 재사용 가능한 예시 함수

```python
# linux_interaction.py
def linux_interaction():
    import sys
    if "linux" not in sys.platform:
        raise RuntimeError("이 함수는 리눅스 시스템에서만 실행 가능합니다.")
    print("리눅스 작업을 수행합니다.")
```

이 함수는 macOS나 Windows에서 호출되면 `RuntimeError`를 발생시킵니다.

### 4.3 ❌ 나쁜 관행: bare `except` + `pass`

```python
try:
    linux_interaction()
except:
    pass   # ❌ 모든 것을 조용히 무시 — 버그까지 포함!
```

프로그램이 충돌하지는 않지만, 무엇이 잘못되었는지에 대한 **모든 정보를 잃게 됩니다**. 이는 파이썬에서 가장 해로운 패턴 중 하나입니다.

### 4.4 ⚠️ 약간 더 나은 방법: 메시지가 있는 bare `except`

```python
try:
    linux_interaction()
except:
    print("리눅스 함수가 실행되지 않았습니다.")
```

이제 *무언가* 실패했다는 것은 알 수 있지만, *무엇이* 실패했는지는 여전히 알 수 없습니다.

### 4.5 ✅ 좋은 관행: 특정 예외 잡기

```python
try:
    linux_interaction()
except RuntimeError as error:
    print(error)
    print("linux_interaction() 함수가 실행되지 않았습니다.")
```

**출력 결과 (macOS 또는 Windows에서):**

```
이 함수는 리눅스 시스템에서만 실행 가능합니다.
linux_interaction() 함수가 실행되지 않았습니다.
```

### 4.6 여러 예외 타입 잡기

여러 개의 `except` 절을 연결할 수 있습니다:

```python
try:
    linux_interaction()
    with open("file.log") as file:
        read_data = file.read()
except FileNotFoundError as fnf_error:
    print(fnf_error)
except RuntimeError as error:
    print(error)
    print("linux_interaction() 함수가 실행되지 않았습니다.")
```

### 4.7 핵심 정리

- `try` 블록은 **첫 번째** 예외를 만나면 즉시 멈춥니다.
- 파이썬은 `except` 절을 **위에서 아래로** 검사하여 일치하는 첫 번째 절을 실행합니다.
- bare `except` 절은 **피하세요** — 예상치 못한 버그를 숨깁니다.
- 항상 `as error`로 예외를 변수에 할당하여 검사할 수 있도록 합니다.

---

## 5단계. `else`로 성공 시 실행하기

`else` 절은 `try` 블록에서 **예외가 발생하지 않았을 때만** 실행됩니다.

### 5.1 구조

```python
try:
    # 시도할 코드
except SomeException:
    # 오류 처리
else:
    # try가 성공했을 때만 실행
```

### 5.2 예시

```python
try:
    linux_interaction()
except RuntimeError as error:
    print(error)
else:
    print("추가 리눅스 작업을 수행합니다.")
```

**리눅스에서:**
```
리눅스 작업을 수행합니다.
추가 리눅스 작업을 수행합니다.
```

**macOS / Windows에서:**
```
이 함수는 리눅스 시스템에서만 실행 가능합니다.
```
(`else` 블록은 **실행되지 않습니다**.)

### 5.3 그냥 블록 뒤에 코드를 두면 안 되나요?

비교해 봅시다:

```python
# 버전 A: else 사용
try:
    linux_interaction()
except RuntimeError as error:
    print(error)
else:
    print("추가 리눅스 작업을 수행합니다.")

# 버전 B: 블록 뒤에 배치
try:
    linux_interaction()
except RuntimeError as error:
    print(error)
print("추가 리눅스 작업을 수행합니다.")
```

**버전 B**에서는 마지막 `print()`가 예외 발생 여부와 **관계없이** 실행됩니다. **버전 A**에서는 **성공했을 때만** 실행됩니다. `else` 절은 의도를 명확히 하고, `try` 블록의 성공에 의존하는 코드를 보호합니다.

---

## 6단계. `finally`로 정리하기

`finally` 절은 예외 발생 여부, 처리 여부와 **무관하게 항상 실행**됩니다.

### 6.1 구조

```python
try:
    # 시도할 코드
except SomeException:
    # 오류 처리
else:
    # 성공 시 실행
finally:
    # 항상 실행 (정리 작업!)
```

### 6.2 예시

```python
try:
    linux_interaction()
except RuntimeError as error:
    print(error)
else:
    try:
        with open("file.log") as file:
            read_data = file.read()
    except FileNotFoundError as fnf_error:
        print(fnf_error)
finally:
    print("예외 발생 여부와 관계없이 정리 작업을 수행합니다.")
```

### 6.3 `finally`의 활용 사례

`finally`는 *반드시* 정리되어야 하는 자원을 해제하기에 적합합니다:

- **파일** 닫기
- **데이터베이스 연결** 닫기
- **네트워크 소켓** 해제
- **락(lock)** 해제

예외가 **잡히지 않아** 프로그램이 종료되려는 상황에서도 `finally` 블록은 종료 직전에 반드시 실행됩니다.

### 6.4 전체 패턴

| 절 | 실행 시점 |
|---|---|
| `try` | 항상 (테스트 대상 코드) |
| `except` | `try`에서 일치하는 예외가 발생했을 때만 |
| `else` | `try`가 **예외 없이** 끝났을 때만 |
| `finally` | **항상** — 예외 발생 여부와 무관 |

---

## 7단계. 사용자 정의 예외 만들기

내장 예외가 상황에 맞지 않을 때는 **`Exception`을 상속**하여 직접 만들 수 있습니다.

### 7.1 최소 사용자 정의 예외

```python
class PlatformException(Exception):
    """호환되지 않는 플랫폼."""
```

이게 전부입니다! 독스트링(docstring)이 문서화 역할과 클래스 본문 역할을 모두 합니다.

### 7.2 사용자 정의 예외 사용하기

```python
class PlatformException(Exception):
    """호환되지 않는 플랫폼."""

def linux_interaction():
    import sys
    if "linux" not in sys.platform:
        raise PlatformException("이 함수는 리눅스 시스템에서만 실행 가능합니다.")
    print("리눅스 작업을 수행합니다.")
```

**출력 결과 (macOS 또는 Windows에서):**

```
Traceback (most recent call last):
  ...
PlatformException: 이 함수는 리눅스 시스템에서만 실행 가능합니다.
```

### 7.3 왜 사용자 정의 예외를 만드나요?

- **설명적인 이름**으로 트레이스백을 더 쉽게 읽을 수 있습니다.
- 무관한 오류를 잘못 잡지 않고 **구체적으로 잡을 수 있습니다**.
- 관련 예외들의 **계층 구조(hierarchy)** 를 만들 수 있습니다:

  ```python
  class PlatformException(Exception):
      """플랫폼 관련 오류의 기본 클래스."""

  class WindowsOnlyException(PlatformException):
      """Windows가 아닌 시스템에서 실행되었을 때 발생."""

  class LinuxOnlyException(PlatformException):
      """리눅스가 아닌 시스템에서 실행되었을 때 발생."""
  ```

  이제 `except PlatformException` 한 줄로 두 자식 클래스를 모두 잡을 수 있습니다.

---

## 키워드 정리

| 키워드 | 용도 |
|---|---|
| `raise` | 예외를 수동으로 발생시킴 |
| `assert` | 개발 단계의 조건을 검증 (`AssertionError` 발생) |
| `try` | 예외가 발생할 수 있는 코드 블록을 표시 |
| `except` | 특정 예외를 잡아 처리 |
| `else` | `try`가 성공했을 때만 코드 실행 |
| `finally` | 예외 발생 여부와 무관하게 정리 코드 실행 |
| `class ... (Exception)` | 사용자 정의 예외 타입 정의 |

---

## 자주 하는 실수 체크리스트

- ❌ bare `except:` 사용 — 버그를 숨김.
- ❌ `except: pass` — 오류를 조용히 삼킴.
- ❌ 운영 로직에 `assert` 사용 — `python -O`로 비활성화됨.
- ❌ 최상위에서 `Exception`을 너무 광범위하게 잡기.
- ✅ 가능한 한 **가장 구체적인** 예외 타입을 잡기.
- ✅ 예외를 처리할 때는 항상 로그를 남기거나 출력하기.
- ✅ 정리 코드는 `try` 블록 뒤가 아니라 `finally`에 두기.
- ✅ 도메인 특화 오류에는 사용자 정의 예외 사용하기.

---

## 더 읽을거리

- 파이썬 공식 문서 — 내장 예외: <https://docs.python.org/3/library/exceptions.html>
- Real Python — 내장 예외 워크스루: <https://realpython.com/python-built-in-exceptions/>
- Real Python — `raise` 심층 분석: <https://realpython.com/python-raise-exception/>
- Real Python — 여러 예외 잡기: <https://realpython.com/python-catch-multiple-exceptions/>
- Real Python — LBYL vs EAFP: <https://realpython.com/python-lbyl-vs-eafp/>
